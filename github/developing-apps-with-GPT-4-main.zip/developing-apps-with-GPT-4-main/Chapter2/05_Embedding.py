result = client.embeddings.create( 
  model="text-embedding-ada-002", input="your text"
)

result['data'][0]['embedding']
